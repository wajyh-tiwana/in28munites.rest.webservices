package com.example.in28munites_rest_webservices.helloworld;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class HelloWorldController {

    @GetMapping( path = "/hello-world")
    public String helloWorld(){
        return "hello world";
    }

    @GetMapping(path = "/hello-world-bean")
    public helloWorldBean helloWorldBean(){
        return new helloWorldBean("Hello World");
    }


    //path parameters
    //user/{id}/todos/{id} =? /users/1/todos/101 // 1 and 101 are path parameters

    //let's build hello world url with a path variable called name

    @GetMapping(path = "/hello-world-bean-path-variable/{name}")
    public helloWorldBean helloWorldPathVariable(@PathVariable String name){
        return new helloWorldBean("Hello World "+name);
    }



}
