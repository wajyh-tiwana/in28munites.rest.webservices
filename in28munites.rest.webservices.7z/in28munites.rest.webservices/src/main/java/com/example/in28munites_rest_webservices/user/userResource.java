package com.example.in28munites_rest_webservices.user;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import javax.validation.Valid;
import java.net.URI;
import java.util.List;

@RestController
public class userResource {

    private UserDaoService service;

    public userResource(UserDaoService service){
        this.service = service;
    }

    @GetMapping("/users")
    public List<User> retrieveAllUsers(){
        return service.findAll();
    }



    @GetMapping("/users/{id}")
    public User retrieveUser(@PathVariable int id){
        User user = service.findOne(id);
        if(user == null){
            throw new UserNotFoundException("User not Found");
        }
        return user;
    }
// need to retest validation
    @PostMapping("/users")
    public ResponseEntity<User> createUser(@Valid @RequestBody User user){
        User savedUser = service.save(user);
        URI location = ServletUriComponentsBuilder.fromCurrentRequest() // currentRequestURL
                .path("/{id}")//id
                .buildAndExpand(savedUser.getId()) //value
                .toUri(); // converted complete url as uri
        return ResponseEntity.created(location).build(); // created will return 201 response code
    }


    @DeleteMapping("/users/{id}")
    public void deleteUser(@PathVariable int id){
         service.deleteById(id);
    }




}
